package codingmason.voxelgame.server;

import java.util.LinkedList;

import codingmason.voxelgame.Chunk;
import codingmason.voxelgame.Data;
import codingmason.voxelgame.Tile;
import codingmason.voxelgame.World;

class Server {
	public World world;
	public String adress;
	public LinkedList<Client> clients = new LinkedList<>();
	public Thread thread = new Thread(() -> run());
	public boolean running = true;
	public int tps = 60;
	
	public Server(String adress, String worldName) {
		this.adress = adress;
		world = new World(worldName);
	}
	
	public void start() {
		genWorld();
		thread.start();
	}
	
	private void genWorld() {
		for(int x = 0; x < 6; x++) {
		for(int y = 0; y < 1; y++) {
		for(int z = 0; z < 6; z++) {
			Chunk c = new Chunk(x, y, z, world);
			for(int xx = 0; xx < Data.CHUNK_WIDTH; xx++) {
			for(int yy = 0; yy < Data.CHUNK_HEIGHT; yy++) {
			for(int zz = 0; zz < Data.CHUNK_DEPTH; zz++) {
				String tile = terrain(xx+x*Data.CHUNK_WIDTH, yy + y*Data.CHUNK_HEIGHT, zz + z*Data.CHUNK_DEPTH);
				c.setTile(xx, yy, zz, tile);
			}
			}
			}
			world.addChunk(c);
		}
		}
		}
	}
	
	public void tick() {
		
	}
	
	public void close() {
		running = false;
	}
	
	public void run() {
		long lastTime = System.nanoTime();
		double ns = 1000000000 / tps;
		double delta = 0;
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta > 0) {
				tick();
				delta--;
			}
		}
	}
	
	private String terrain(int x, int y, int z) {
		if(y <= 0) return Tile.bedrock+"";
		
		double heightMapScale = 4.5;
		double freq = 0.01;
		
		double heightMap = PerlinNoise.noise((double)x*freq, (double)z*freq)*heightMapScale+5;
		heightMap *= heightMapScale;
		int hmi = (int)heightMap;
		
		if(y > hmi) return Tile.air+"";
		if(y == hmi) return Tile.grass_block+"";
		if(y > hmi-4 & y < hmi) return Tile.dirt+"";
		if(y <= hmi-4 & y > 0) return Tile.stone+"";
		
		return Tile.air+"";
	}
}
