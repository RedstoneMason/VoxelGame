package codingmason.voxelgame.server;

import codingmason.voxelgame.World;

public class ClientServer {
	private String adress = "local", worldName;
	private World world;
	private Server server;
	
	public ClientServer(String worldName) {
		this.worldName = worldName;
	}
	
	private void run() {
		server = new Server(adress, worldName);
		server.start();
		world = server.world;
	}
	
	public String exec(String command) {
		String[] args = command.split(" ");
		if(command.startsWith("server.run")) {
			run();
			return "1";
		}
		if(command.startsWith("server.close")) {
			server.close();
			return "1";
		}
		if(command.startsWith("world.properties")) {
			if(world == null) return "0:world=null";
			return "1:"+world.getProperties();
		}
		if(command.startsWith("world.chunks")) {
			if(world == null) return "0:world=null";
			return "1:"+world.getChunksStr();
		}
		if(command.startsWith("world.set_tile")) {
			if(world == null) return "0:world=null";
			int x = Integer.parseInt(args[1]);
			int y = Integer.parseInt(args[2]);
			int z = Integer.parseInt(args[3]);
			String tile = args[4];
			world.setTile(x, y, z, tile);
		}
		return "0:unkown_command";
	}
}
