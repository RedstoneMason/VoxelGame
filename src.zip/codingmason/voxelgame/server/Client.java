package codingmason.voxelgame.server;

class Client {

}
