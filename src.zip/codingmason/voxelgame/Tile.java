package codingmason.voxelgame;

public class Tile {
	public static final int air = 0, stone = 1, dirt = 2, grass = 3, bedrock = 4, glass = 5, grass_block = 6;

	public static String setData(String tile, int index, int value) {
		if(!hasData(tile) || index < 0) return tile;
		String[] parts = tile.split("&");
		if(index >= parts.length) return tile;
		int[] data = new int[parts.length - 1];
		for(int i = 0; i < data.length; i++) data[i] = Integer.parseInt(parts[i + 1]);
		data[index] = value;
		return addData(getID(tile)+"", data);
	}

	public static String addData(String tile, int...data) {
		for(int v : data) tile += "&"+v;
		return tile;
	}

	public static boolean hasData(String tile) {
		return tile.contains("&");
	}

	public static int getID(String tile) {
		if(!hasData(tile)) return Integer.parseInt(tile);
		return Integer.parseInt(tile.split("&")[0]);
	}

	public static int[] getData(String tile) {
		if(!hasData(tile)) return new int[] {};
		String[] parts = tile.split("&");
		int[] data = new int[parts.length - 1];
		for(int i = 0; i < data.length; i++) data[i] = Integer.parseInt(parts[i + 1]);
		return data;
	}

	public static boolean blocks(String tile, String test) {
		int testID = getID(test), tileID = getID(tile);
		if(tileID == Tile.air) return true;
		if(testID == tileID) {
			return true;
		}
		return switch(testID) {
			case air -> false;
			case glass -> false;
			default -> true;
		};
	}
}
