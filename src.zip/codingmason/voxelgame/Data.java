package codingmason.voxelgame;

import codingmason.gdt.vectors.V2f;
import codingmason.gdt.vectors.V3;
import codingmason.gdt.vectors.V3f;

public class Data {
	public static final int CHUNK_WIDTH = 16, CHUNK_HEIGHT = 32, CHUNK_DEPTH = 16;
	public static final V3f[][] verticies = new V3f[][] {
			new V3f[] {new V3f(0, 0, 1), new V3f(1, 0, 1), new V3f(1, 1, 1), new V3f(0, 1, 1)}, //+Z
			new V3f[] {new V3f(0, 0, 0), new V3f(0, 1, 0), new V3f(1, 1, 0), new V3f(1, 0, 0)}, //-Z
			new V3f[] {new V3f(1, 0, 0), new V3f(1, 1, 0), new V3f(1, 1, 1), new V3f(1, 0, 1)}, //+X
			new V3f[] {new V3f(0, 0, 0),  new V3f(0, 0, 1), new V3f(0, 1, 1), new V3f(0, 1, 0)}, //-X
			new V3f[] {new V3f(0, 1, 0),  new V3f(0, 1, 1), new V3f(1, 1, 1), new V3f(1, 1, 0)}, //+Y
			new V3f[] {new V3f(0, 0, 0),  new V3f(1, 0, 0), new V3f(1, 0, 1), new V3f(0, 0, 1)}, //-Y
	};
	public static final int[] indicies = new int[] {
		0, 1, 3, 3, 1, 2
	};
	public static final V2f[][] maps = new V2f[][] {{
		new V2f(0, 1), // +Z
		new V2f(1, 1), 
		new V2f(1, 0), 
		new V2f(0, 0),
		}, {
		new V2f(1, 1), // -Z
		new V2f(1, 0), 
		new V2f(0, 0), 
		new V2f(0, 1),
		}, {
		new V2f(1, 1), // +X
		new V2f(1, 0), 
		new V2f(0, 0), 
		new V2f(0, 1),
		}, {
		new V2f(0, 1), // -X 
		new V2f(1, 1), 
		new V2f(1, 0), 
		new V2f(0, 0),
		}, {
		new V2f(1, 1), // +Y
		new V2f(1, 0), 
		new V2f(0, 0), 
		new V2f(0, 1),
		}, {
		new V2f(1, 1), // -Y
		new V2f(1, 0), 
		new V2f(0, 0), 
		new V2f(0, 1),
		}, 
	};
	public static final V3[] faceChecks = new V3[] {
		new V3(0, 0, 1), //+Z
		new V3(0, 0, -1), //-Z
		new V3(1, 0, 0), //+X
		new V3(-1, 0, 0), //-X
		new V3(0, 1, 0), //+y
		new V3(0, -1, 0), //-Y
	};
}
