package codingmason.voxelgame.client;

import java.io.File;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL30;

import codingmason.gdt.extensions.Arrays;
import codingmason.gdt.extensions.Files;
import codingmason.gdt.tools.List;
import codingmason.gdt.vectors.V2f;
import codingmason.gdt.vectors.V3;
import codingmason.gdt.vectors.V3f;
import codingmason.gdt.vectors.V4f;
import codingmason.voxelgame.Chunk;
import codingmason.voxelgame.Data;
import codingmason.voxelgame.Tile;
import codingmason.voxelgame.World;
import codingmason.voxelgame.server.ClientServer;
import codingmason.wgm.Program;

public class Main extends Program {
	public static String dir = System.getProperty("user.home")+"/CodingMason/VoxelGame";
	private ClientServer server = new ClientServer("Test");
	private Window window;
	private Renderer renderer;
	private Shader shader;
	private World world = new World("");
	private List<ChunkMesh> chunkMeshs = new List<>();
	private ColorMesh mesh;
	private Camera cam;
	private boolean initialized;
	private V3 edit;
	private TileI tileEdit;

	public static void main(String[] args) {
		new Main();
	}

	public Main() {
		//super.setTPS(60);
		super.runProgram();
	}

	public void setMesh(V3 pos) {
		if(pos == null) {
			edit = null;
			mesh = null;
			return;
		}
		edit = pos;
		List<V3f> verticies = new List<>();
		List<Integer> indicies = new List<>();
		int indiceIndex = 0;
		for(int i = 0; i < 6; i++) {
			verticies.add(pos.toFloat().add(Data.verticies[i][0]));
			verticies.add(pos.toFloat().add(Data.verticies[i][1]));
			verticies.add(pos.toFloat().add(Data.verticies[i][2]));
			verticies.add(pos.toFloat().add(Data.verticies[i][3]));
			for(int l : Data.indicies) indicies.add(l+indiceIndex);
			indiceIndex += 4;
		}
		if(mesh != null) mesh.destroy();
		mesh = new ColorMesh(verticies.toArray(new V3f[] {}), Arrays.toPrimitive(indicies.toArray(new Integer[] {})), new V4f(1f, 0f, 1f, 0.6f), new V3f(0, 0, 0));
		mesh.create();
	}

	public void updateWorld() {
		String s = server.exec("world.chunks");
		world.setChunksStr(s);
	}
	
	public void loadChunks() {
		for(ChunkMesh cm : chunkMeshs) {
			cm.destroy();
		}
		chunkMeshs.clear();
		chunkMeshs.allocate(world.getChunks().size());
		for(Chunk c : world.getChunks()) {
			ChunkMesh cm = new ChunkMesh(c);
			cm.create();
			chunkMeshs.add(cm);
		}
	}

	public void init() {
		window = new Window(1000, 750, "Game");
		shader = new Shader(Files.read(new File(dir+"/shaders/mainVertex.glsl")), Files.read(new File(dir+"/shaders/mainFragment.glsl")));
		window.setBackgroundColor(0f, 0.6f, 1f);
		window.create();
		shader.create();
		GLFW.glfwSetInputMode(window.getID(), GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_DISABLED);
		Mat.load(new File(dir+"/textures"));

		cam = new Camera(new V3f(0, 0, 1), new V3f(0, 0, 0), window.getInput());
		renderer = new Renderer(shader, window.getProjectionMatrix(), cam);
		
		server.exec("server.run");
		updateWorld();
		loadChunks();

		GL30.glEnable(GL30.GL_DEPTH_TEST);
		GL30.glEnable(GL30.GL_CULL_FACE);
		GL30.glEnable(GL30.GL_BLEND);
		GL30.glEnable(GL30.GL_TEXTURE_2D);
		GL30.glEnable(GL30.GL_ALPHA_TEST_FUNC);
		GL30.glEnable(GL30.GL_ALPHA_TEST);

		GL30.glDepthFunc(GL30.GL_LEQUAL);
		GL30.glCullFace(GL30.GL_BACK);
		GL30.glBlendFunc(GL30.GL_SRC_ALPHA, GL30.GL_ONE_MINUS_SRC_ALPHA);
		GL30.glAlphaFunc(GL30.GL_GREATER, 0.5F);
		
		cam.resetTime();
		
		initialized = true;
	}
	
	private void setTile(int x, int y, int z, String tile) {
		Chunk c = world.contains(x, y, z);
		if(c != null) {
			c.setTile(x-c.x*Data.CHUNK_WIDTH, y-c.y*Data.CHUNK_HEIGHT, z-c.z*Data.CHUNK_DEPTH, tile);
			for(ChunkMesh cm : chunkMeshs) {
				if(cm.getChunk() == c) {
					cm.destroy();
					cm.setEdited(true);
				}
			}
		}
	}
	
	private void pickTile() {
		// Calculate the normalized device coordinates
		V2f mouseCoords = new V2f(2f / window.getWidth(), 2f / window.getHeight());
		V4f mouseNDS = new V4f((float)mouseCoords.x, (float)mouseCoords.y, -1f, 1f);     

		// Calculate the ray in cam space 
		V4f eyeRay = new V4f(Matrix.multiply(Matrix.inverse(window.getProjectionMatrix()), mouseNDS.getValues()));
		eyeRay = new V4f(eyeRay.x, eyeRay.y, eyeRay.z, 0f);

		// Calculate the ray in world space
		V4f worldRay4f = new V4f(Matrix.multiply(Matrix.inverse(Matrix.view(cam.getPos(), cam.getRot())), eyeRay.getValues()));
		V3f worldRay = new V3f(Matrix.normalize(new V3f(worldRay4f.x, worldRay4f.y, worldRay4f.z).getValues()));
		V3f v = cam.getPos().clone();
		for(float i = 0; i < 30; i+=0.9f) {
			v = v.add(worldRay);
			String tile = world.getTile((int)v.x, (int)v.y, (int)v.z);
			if(tile == null) continue;
			if(tile.equals(Tile.air+"")) continue;
			setMesh(v.toInt());
			return;
		}
		setMesh(null);
	}

	protected void programRender() {
		if(!initialized) init();
		Input in = window.getInput();
		if(window.shouldClose() || in.keyIsPressed(GLFW.GLFW_KEY_ESCAPE)) {
			window.destroy();
			shader.destroy();
			server.exec("server.close");
			super.closeProgram();
		}
		if(in.lastButtonPressed() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
			if(edit != null)
			setTile(edit.x, edit.y, edit.z, Tile.air+"");
		}
		if(in.lastButtonPressed() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
			if(edit != null)
			setTile(edit.x, edit.y, edit.z, Tile.glass+"");
		}
		if(in.lastKeyPressed() == GLFW.GLFW_KEY_R) {
			updateWorld();
			loadChunks();
		}
		if(in.lastKeyPressed() == GLFW.GLFW_KEY_E) {
			cam.setPos(new V3f(0, 0, 0));
			cam.setRot(new V3f(0, 0, 0));
		}
		in.checked();
		
		window.update();
		cam.update();
		
		for(ChunkMesh cm : chunkMeshs) {
			if(cm.isEdited()) cm.create();
		}
		
		pickTile();
		
		renderer.update();
		for(ChunkMesh cm : chunkMeshs) {
			renderer.renderChunkMesh(cm);
		}
		if(mesh != null) renderer.renderColorMesh(mesh);
		
		window.swapBuffers();
	}

	protected void programTick() {
		if(!initialized) return;
	}
}
