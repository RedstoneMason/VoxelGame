package codingmason.voxelgame.client;

public class TileI {
	public static final int PX = 1, NX = 2, PZ = 3, NZ = 3, PY = 4, NY = 5;
	
	public int face, x, y, z;
	
	public TileI(int face, int x, int y, int z) {
		this.face = face;
		this.x = x;
		this.y = y;
		this.z = z;
	}
}
