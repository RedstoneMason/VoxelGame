package codingmason.voxelgame.client;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.glfw.GLFWWindowSizeCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;

import codingmason.gdt.vectors.V3f;

class Window {
	private int width, height, frames;
	private long id, time;
	private String title;
	private V3f background = new V3f(0, 0, 0);
	private GLFWWindowSizeCallback sizeCallback;
	private boolean isResized, isFullscreen;
	private int[] windowPosX = new int[1], windowPosY = new int[1];
	private Matrix projection;
	private Input input;
	
	public Window(int width, int height, String title) {
		this.width = width;
		this.height = height;
		this.title = title;
		projection = Matrix.projection(70.0f, (float) width / (float) height, 0.1f, 1000.0f);
	}
	
	public void create() {
		if(!GLFW.glfwInit()) {
			System.err.println("ERROR: GLFW wasn't initializied");
			return;
		}
		
		id = GLFW.glfwCreateWindow(width, height, title, isFullscreen ? GLFW.glfwGetPrimaryMonitor() : 0, 0);
		
		if(id == 0) {
			System.err.println("ERROR: Window wasn't created");
			return;
		}
		
		input = new Input(id);
		
		GLFWVidMode videoMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
		windowPosX[0] = (videoMode.width() - width) / 2;
		windowPosY[0] = (videoMode.height() - height) / 2;
		GLFW.glfwSetWindowPos(id, windowPosX[0], windowPosY[0]);
		GLFW.glfwMakeContextCurrent(id);
		GL.createCapabilities();
		
		createCallbacks();
		
		GLFW.glfwShowWindow(id);
		GLFW.glfwSwapInterval(1);
		
		time = System.currentTimeMillis();
	}
	
	private void createCallbacks() {
		sizeCallback = new GLFWWindowSizeCallback() {
			public void invoke(long window, int w, int h) {
				width = w;
				height = h;
				isResized = true;
			}
		};
	}
	
	public void update() {
		if(isResized) {
			GL11.glViewport(0, 0, width, height);
			isResized = false;
		}
		GL11.glClearColor(background.getX(), background.getY(), background.getZ(), 1.0f);
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GLFW.glfwPollEvents();
		frames++;
		if(System.currentTimeMillis() > time + 1000) {
			GLFW.glfwSetWindowTitle(id, title + " | FPS: " + frames);
			time = System.currentTimeMillis();
			frames = 0;
		}
	}
	
	public void swapBuffers() {
		GLFW.glfwSwapBuffers(id);
	}
	
	public boolean shouldClose() {
		return GLFW.glfwWindowShouldClose(id);
	}
	
	public void destroy() {
		sizeCallback.free();
		GLFW.glfwWindowShouldClose(id);
		GLFW.glfwDestroyWindow(id);
		GLFW.glfwTerminate();
	}
	
	public void setBackgroundColor(float r, float g, float b) {
		background = new V3f(r, g, b);
	}

	public boolean isFullscreen() {
		return isFullscreen;
	}

	public void setFullscreen(boolean isFullscreen) {
		this.isFullscreen = isFullscreen;
		isResized = true;
		if (isFullscreen) {
			GLFW.glfwGetWindowPos(id, windowPosX, windowPosY);
			GLFW.glfwSetWindowMonitor(id, GLFW.glfwGetPrimaryMonitor(), 0, 0, width, height, 0);
		} else {
			GLFW.glfwSetWindowMonitor(id, 0, windowPosX[0], windowPosY[0], width, height, 0);
		}
	}
	
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	public String getTitle() {
		return title;
	}
	public long getID() {
		return id;
	}

	public Matrix getProjectionMatrix() {
		return projection;
	}
	
	public Input getInput() {
		return input;
	}
}
