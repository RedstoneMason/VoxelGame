package codingmason.voxelgame.client;

import org.lwjgl.glfw.GLFW;

import codingmason.gdt.vectors.V3f;

class Camera {
	private V3f pos, rot;
	private float moveSpeed = 1.8f, mouseSensitivity = 0.15f, distance = 2.0f, horizontalAngle = 0, verticalAngle = 0;
	private double oldMouseX = 0, oldMouseY = 0, newMouseX, newMouseY;
	private long lastTime = System.nanoTime(), passedTime;
	private Input input;

	public Camera(V3f position, V3f rotation, Input input) {
		this.pos = position;
		this.rot = rotation;
		this.input = input;
	}
	
	public void updateTime() {
		long now = System.nanoTime();
		passedTime = now - lastTime;
		lastTime = now;
	}
	public void resetTime() {
		this.passedTime = 0;
		this.lastTime = System.nanoTime();
	}

	public void update() {
		updateTime();
		newMouseX = input.mouseX();
		newMouseY = input.mouseY();

		double ns_1s = 100000000; // 1B
		
		float x = (float)(Math.sin(Math.toRadians(rot.getY())) * moveSpeed * ((double)passedTime / ns_1s));
		float z = (float)(Math.cos(Math.toRadians(rot.getY())) * moveSpeed * ((double)passedTime / ns_1s));
		float y = (float)(moveSpeed * (passedTime / ns_1s));
		
		if(input.keyIsPressed(GLFW.GLFW_KEY_A)) pos = pos.add(new V3f(-z, 0, x));
		if(input.keyIsPressed(GLFW.GLFW_KEY_D)) pos = pos.add(new V3f(z, 0, -x));
		if(input.keyIsPressed(GLFW.GLFW_KEY_W)) pos = pos.add(new V3f(-x, 0, -z));
		if(input.keyIsPressed(GLFW.GLFW_KEY_S)) pos = pos.add(new V3f(x, 0, z));
		if(input.keyIsPressed(GLFW.GLFW_KEY_SPACE)) pos = pos.add(new V3f(0, y, 0));
		if(input.keyIsPressed(GLFW.GLFW_KEY_LEFT_SHIFT)) pos = pos.add(new V3f(0, -y, 0));
		
		float dx = (float)(newMouseX - oldMouseX);
		float dy = (float)(newMouseY - oldMouseY);

		rot = rot.add(new V3f(-dy * mouseSensitivity, -dx * mouseSensitivity, 0));

		oldMouseX = newMouseX;
		oldMouseY = newMouseY;
	}

	public void update(BasicMesh mesh, V3f pos) {
		newMouseX = input.mouseX();
		newMouseY = input.mouseY();

		float dx = (float)(newMouseX - oldMouseX);
		float dy = (float)(newMouseY - oldMouseY);

		if(input.buttonIsPressed(GLFW.GLFW_MOUSE_BUTTON_LEFT)) {
			verticalAngle -= dy * mouseSensitivity;
			horizontalAngle += dx * mouseSensitivity;
		}
		if(input.buttonIsPressed(GLFW.GLFW_MOUSE_BUTTON_RIGHT)) {
			if(distance > 0) {
				distance += dy * mouseSensitivity / 4;
			} else {
				distance = 0.1f;
			}
		}

		float horizontalDistance = (float)(distance * Math.cos(Math.toRadians(verticalAngle)));
		float verticalDistance = (float)(distance * Math.sin(Math.toRadians(verticalAngle)));

		float xOffset = (float)(horizontalDistance * Math.sin(Math.toRadians(-horizontalAngle)));
		float zOffset = (float)(horizontalDistance * Math.cos(Math.toRadians(-horizontalAngle)));

		pos = new V3f(pos.getX() + xOffset, pos.getY() - verticalDistance, pos.getZ() + zOffset);

		rot = new V3f(verticalAngle, -horizontalAngle, 0);

		oldMouseX = newMouseX;
		oldMouseY = newMouseY;
	}
	
	public void setPos(V3f pos) {
		this.pos = pos;
	}
	public void setRot(V3f rot) {
		this.rot = rot;
	}

	public V3f getPos() {
		return pos;
	}
	public V3f getRot() {
		return rot;
	}
}