package codingmason.voxelgame.client;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import codingmason.gdt.tools.List;
import codingmason.gdt.vectors.V3;
import codingmason.gdt.vectors.V3f;
import codingmason.voxelgame.Chunk;
import codingmason.voxelgame.Data;
import codingmason.voxelgame.Tile;

class ChunkMesh {
	private List<Vertex> verticies = new List<>();
	private List<FaceMesh> faceMeshs = new List<>();
	private DataBuffer pb, tb;
	private int vao;
	private Chunk chunk;
	private boolean edited = false;
	
	public ChunkMesh(Chunk chunk) {
		this.chunk = chunk;
	}
	
	public void create() {
		edited = false;
		int WIDTH = Data.CHUNK_WIDTH, HEIGHT = Data.CHUNK_HEIGHT, DEPTH = Data.CHUNK_DEPTH;
		int indiceIndex = 0;
		for(int x = 0; x < WIDTH; x++) {
		for(int y = 0; y < HEIGHT; y++) {
		for(int z = 0; z < DEPTH; z++) {
			String tile = chunk.getTile(x, y, z);
			int xx = chunk.x * WIDTH + x, yy = chunk.y * HEIGHT + y, zz = chunk.z * DEPTH + z;
			V3f pos = new V3f(xx, yy, zz);
			for(int i = 0; i < 6; i++) {
				V3 v = new V3(x, y, z).add(Data.faceChecks[i]);
				if(Tile.blocks(chunk.getTile(x, y, z), chunk.getTile(v.x, v.y, v.z))) continue;
				verticies.add(new Vertex(pos.add(Data.verticies[i][0]), Data.maps[i][0]));
				verticies.add(new Vertex(pos.add(Data.verticies[i][1]), Data.maps[i][1]));
				verticies.add(new Vertex(pos.add(Data.verticies[i][2]), Data.maps[i][2]));
				verticies.add(new Vertex(pos.add(Data.verticies[i][3]), Data.maps[i][3]));
				int[] indicies = new int[6];
				for(int l = 0; l < 6; l++) indicies[l] = Data.indicies[l]+indiceIndex;
				indiceIndex += 4;
				
				IntBuffer indiciesBuffer = MemoryUtil.memAllocInt(indicies.length);
				indiciesBuffer.put(indicies).flip();
				
				DataBuffer ib = new DataBuffer(indiciesBuffer);
				ib.create();
				
				faceMeshs.add(new FaceMesh(indicies, getMatForTile(tile, i), ib));
			}
		}
		}
		}
		
		vao = GL30.glGenVertexArrays();
		GL30.glBindVertexArray(vao);
		
		FloatBuffer positionBuffer = MemoryUtil.memAllocFloat(verticies.size() * 3);
		float[] positionData = new float[verticies.size() * 3];
		for (int i = 0; i < verticies.size(); i++) {
			positionData[i * 3] = verticies.get(i).getX();
			positionData[i * 3 + 1] = verticies.get(i).getY();
			positionData[i * 3 + 2] = verticies.get(i).getZ();
		}
		positionBuffer.put(positionData).flip();
		
		pb = new DataBuffer(positionBuffer, 0, 3);
		pb.create();
		
		FloatBuffer textureBuffer = MemoryUtil.memAllocFloat(verticies.size() * 2);
		float[] textureData = new float[verticies.size() * 2];
		for (int i = 0; i < verticies.size(); i++) {
			textureData[i * 2] = verticies.get(i).getMap().getX();
			textureData[i * 2 + 1] = verticies.get(i).getMap().getY();
		}
		textureBuffer.put(textureData).flip();
		
		tb = new DataBuffer(textureBuffer, 2, 2);
		tb.create();
	}
	
	public static Mat getMatForTile(String tile, int i) {
		String txt;
		switch(Tile.getID(tile)) {
			case Tile.dirt: txt = "dirt";break;
			case Tile.stone: txt = "stone";break;
			case Tile.glass: txt = "glass";break;
			case Tile.grass_block:
				if(Data.faceChecks[i].y == 1) txt = "grass";
				else if(Data.faceChecks[i].y == -1) txt = "dirt";
				else txt = "grass_block";
				break;
			case Tile.bedrock: txt = "hard_stone";break;
			default: txt = "missing";break;
		};
		return Mat.get(txt);
	}
	
	public void destroy() {
		for(FaceMesh fm : faceMeshs) {
			fm.destroy();
		}
		faceMeshs.clear();
		verticies.clear();
		pb.destroy();
		tb.destroy();
		GL30.glDeleteVertexArrays(vao);
	}
	
	public void setEdited(boolean edited) {
		this.edited = edited;
	}
	
	public Chunk getChunk() {
		return chunk;
	}
	public int getVAO() {
		return vao;
	}
	public DataBuffer getPB() {
		return pb;
	}
	public DataBuffer getTB() {
		return tb;
	}
	public boolean isEdited() {
		return edited;
	}
	public List<FaceMesh> getFaceMeshs() {
		return faceMeshs;
	}
}
