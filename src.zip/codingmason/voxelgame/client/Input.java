package codingmason.voxelgame.client;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWKeyCallback;
import org.lwjgl.glfw.GLFWMouseButtonCallback;
import org.lwjgl.glfw.GLFWScrollCallback;

class Input {
	private boolean[] keys = new boolean[GLFW.GLFW_KEY_LAST];
	private boolean[] buttons = new boolean[GLFW.GLFW_MOUSE_BUTTON_LAST];
	private double mouseX, mouseY;
	private double scrollX, scrollY;
	private int lastKeyPressed = -1, lastButtonPressed = -1;
	
	private GLFWKeyCallback keyCb;
	private GLFWCursorPosCallback cursorPosCb;
	private GLFWMouseButtonCallback mouseButtonCb;
	private GLFWScrollCallback scrollCb;
	
	public Input(long window) {
		keyCb = new GLFWKeyCallback() {
			public void invoke(long window, int key, int scancode, int action, int mods) {
				keys[key] = (action != GLFW.GLFW_RELEASE);
				if(keys[key]) lastKeyPressed = key;
			}
		};
		cursorPosCb = new GLFWCursorPosCallback() {
			public void invoke(long window, double xpos, double ypos) {
				mouseX = xpos;
				mouseY = ypos;
			}
		};
		mouseButtonCb = new GLFWMouseButtonCallback() {
			public void invoke(long window, int button, int action, int mods) {
				buttons[button] = (action != GLFW.GLFW_RELEASE);
				if(buttons[button]) lastButtonPressed = button;
			}
		};
		scrollCb = new GLFWScrollCallback() {
			public void invoke(long window, double offsetx, double offsety) {
				scrollX += offsetx;
				scrollY += offsety;
			}
		};
		GLFW.glfwSetMouseButtonCallback(window, mouseButtonCb);
		GLFW.glfwSetKeyCallback(window, keyCb);
		GLFW.glfwSetCursorPosCallback(window, cursorPosCb);
		GLFW.glfwSetScrollCallback(window, scrollCb);
	}
	
	public void checked() {
		lastKeyPressed = -1;
		lastButtonPressed = -1;
	}
	
	public boolean keyIsPressed(int key) {
		return keys[key];
	}
	public boolean buttonIsPressed(int button) {
		return buttons[button];
	}
	public int lastKeyPressed() {
		return lastKeyPressed;
	}
	public int lastButtonPressed() {
		return lastButtonPressed;
	}
	public double mouseX() {
		return mouseX;
	}
	public double mouseY() {
		return mouseY;
	}
	public double scrollX() {
		return scrollX;
	}
	public double scrollY() {
		return scrollY;
	}
	
	public void destroy() {
		keyCb.free();
		cursorPosCb.free();
		mouseButtonCb.free();
		scrollCb.free();
	}
}