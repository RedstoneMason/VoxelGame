package codingmason.voxelgame.client;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import codingmason.gdt.vectors.V3f;
import codingmason.gdt.vectors.V4f;

public class ColorMesh {
	private V3f[] vertices;
	private int[] indices;
	private V3f rot = new V3f(0, 0, 0);
	private int vao;
	private DataBuffer pb, ib, tb;
	private boolean frame;
	private V4f color;
	
	public ColorMesh(V3f[] vertices, int[] indices, V4f color, V3f rot) {
		this.rot = rot;
		this.vertices = vertices;
		this.indices = indices;
		this.color = color;
	}

	public void create() {
		vao = GL30.glGenVertexArrays();
		GL30.glBindVertexArray(vao);
		
		FloatBuffer positionBuffer = MemoryUtil.memAllocFloat(vertices.length * 3);
		float[] positionData = new float[vertices.length * 3];
		for (int i = 0; i < vertices.length; i++) {
			positionData[i * 3] = vertices[i].getX();
			positionData[i * 3 + 1] = vertices[i].getY();
			positionData[i * 3 + 2] = vertices[i].getZ();
		}
		positionBuffer.put(positionData).flip();
		
		pb = new DataBuffer(positionBuffer, 0, 3);
		pb.create();
		
		FloatBuffer textureBuffer = MemoryUtil.memAllocFloat(vertices.length * 2);
		float[] textureData = new float[vertices.length * 2];
		for (int i = 0; i < vertices.length; i++) {
			textureData[i * 2] = 0;
			textureData[i * 2 + 1] = 0;
		}
		textureBuffer.put(textureData).flip();
		
		tb = new DataBuffer(textureBuffer, 2, 2);
		tb.create();
		
		IntBuffer indicesBuffer = MemoryUtil.memAllocInt(indices.length);
		indicesBuffer.put(indices).flip();
		
		ib = new DataBuffer(indicesBuffer);
		ib.create();
	}
	
	public void destroy() {
		pb.destroy();
		ib.destroy();
		GL30.glDeleteVertexArrays(vao);
	}

	public void setRot(V3f rot) {
		this.rot = rot;
	}
	public void setFrame(boolean frame) {
		this.frame = frame;
	}
	
	public boolean isFrame() {
		return frame;
	}
	public V3f[] getVertices() {
		return vertices;
	}
	public V3f getRot() {
		return rot;
	}
	public int[] getIndices() {
		return indices;
	}
	public int getVAO() {
		return vao;
	}
	public DataBuffer getPB() {
		return pb;
	}
	public DataBuffer getIB() {
		return ib;
	}
	public DataBuffer getTB() {
		return tb;
	}
	public V4f getColor() {
		return color;
	}
}
