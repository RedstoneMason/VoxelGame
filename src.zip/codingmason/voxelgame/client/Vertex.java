package codingmason.voxelgame.client;

import codingmason.gdt.vectors.V2f;
import codingmason.gdt.vectors.V3f;

class Vertex {
	private V3f pos;
	private V2f map;
	
	public Vertex(V3f pos, V2f map) {
		this.pos = pos;
		this.map = map;
	}
	
	public float getX() {
		return pos.x;
	}
	public float getY() {
		return pos.y;
	}
	public float getZ() {
		return pos.z;
	}

	public V3f getPos() {
		return pos;
	}
	public V2f getMap() {
		return map;
	}
}