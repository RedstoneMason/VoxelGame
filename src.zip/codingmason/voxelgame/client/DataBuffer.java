package codingmason.voxelgame.client;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.opengl.GL30;

class DataBuffer {
	private int id, index, size;
	private FloatBuffer fbuffer;
	private IntBuffer ibuffer;
	
	public DataBuffer(FloatBuffer buffer, int index, int size) {
		this.fbuffer = buffer;
		this.index = index;
		this.size = size;
	}
	public DataBuffer(IntBuffer buffer) {
		this.ibuffer = buffer;
	}
	
	public void create() {
		if(ibuffer != null) {
			id = GL30.glGenBuffers();
			bind();
			GL30.glBufferData(GL30.GL_ELEMENT_ARRAY_BUFFER, ibuffer, GL30.GL_STATIC_DRAW);
			unbind();
		}
		else {
			id = GL30.glGenBuffers();
			bind();
			GL30.glBufferData(GL30.GL_ARRAY_BUFFER, fbuffer, GL30.GL_STATIC_DRAW);
			GL30.glVertexAttribPointer(index, size, GL30.GL_FLOAT, false, 0, 0);
			unbind();
		}
	}
	
	public void destroy() {
		if(fbuffer != null) fbuffer.clear();
		if(ibuffer != null) ibuffer.clear();
		GL30.glDeleteBuffers(id);
	}
	
	public void bind() {
		if(ibuffer != null) {
			GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, id);
		}
		else {
			GL30.glBindBuffer(GL30.GL_ARRAY_BUFFER, id);
		}
	}
	
	public void unbind() {
		if(ibuffer != null) {
			GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		else {
			GL30.glBindBuffer(GL30.GL_ARRAY_BUFFER, 0);
		}
	}
	
	public int getID() {
		return id;
	}
}
