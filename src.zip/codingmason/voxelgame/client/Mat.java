package codingmason.voxelgame.client;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;

import codingmason.gdt.extensions.Files;
import codingmason.gdt.tools.List;

class Mat {
	private static List<Mat> mats = new List<>();
	private File textureFile;
	private float width, height;
	private int textureID;

	public Mat(File textureFile) {
		this.textureFile = textureFile;
	}
	
	public static Mat get(String name) {
		for(Mat m : mats) {
			String fn = m.textureFile.getName();
			if(fn.substring(0, fn.length()-4).equals(name)) return m;
		}
		System.err.println("couldnt locate texture '"+name+"'");
		return null;
	}
	
	public static void load(File dir) {
		File[] txts = Files.getChilderen(dir, "png");
		mats.allocate(txts.length);
		for(File f : txts) {
			Mat mat = new Mat(f);
			mat.create();
			mats.add(mat);
		}
	}

	private void create() {
		BufferedImage img = null;
		try {
			img = ImageIO.read(textureFile);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		if(img == null) return;
		int[] pixels = new int[img.getWidth() * img.getHeight()];
		for(int x = 0; x < img.getWidth(); x++) {
			for(int y = 0; y < img.getHeight(); y++) {
				pixels[x + y * img.getWidth()] = img.getRGB(x, y);
			}
		}
		textureID = GL30.glGenTextures();
		// Valid format options: 6410 - 6406
		// Blur textures: filter = GL30.GL_LINEAR
		int target = GL30.GL_TEXTURE_2D, filter = GL30.GL_NEAREST, format = GL30.GL_RGBA, format2 = GL30.GL_BGRA;
		GL30.glBindTexture(target, textureID);
		GL30.glTexParameteri(target, GL30.GL_TEXTURE_MIN_FILTER, filter);
		GL30.glTexParameteri(target, GL30.GL_TEXTURE_MAG_FILTER, filter);
		GL30.glTexImage2D(target, 0, format, get2Fold(img.getWidth()), get2Fold(img.getHeight()), 0, format2, GL30.GL_UNSIGNED_BYTE, pixels);
	}

	private static int get2Fold(int fold) {
		int ret = 2;
		while(ret < fold) ret *= 2;
		return ret;
	}
	
	public static void destroyMats() {
		for(Mat m : mats) {
			m.destroy();
		}
	}
	
	public void bind() {
		GL30.glBindTexture(GL30.GL_TEXTURE_2D, textureID);
	}
	
	public void unbind() {
		GL30.glBindTexture(GL30.GL_TEXTURE_2D, 0);
	}

	private void destroy() {
		GL13.glDeleteTextures(textureID);
	}

	public float getWidth() { return width; }
	public float getHeight() { return height; }
	public int getTextureID() { return textureID; }
}
