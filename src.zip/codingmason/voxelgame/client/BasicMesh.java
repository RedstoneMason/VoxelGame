package codingmason.voxelgame.client;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import codingmason.gdt.vectors.V3f;

class BasicMesh {
	private Vertex[] vertices;
	private int[] indices;
	private Mat mat;
	private V3f rot = new V3f(0, 0, 0);
	private int vao;
	private DataBuffer pb, ib, tb;
	private boolean frame;
	
	public BasicMesh(Vertex[] vertices, int[] indices, Mat mat, V3f rot) {
		this.rot = rot;
		this.vertices = vertices;
		this.indices = indices;
		this.mat = mat;
	}

	public void create() {
		vao = GL30.glGenVertexArrays();
		GL30.glBindVertexArray(vao);
		
		FloatBuffer positionBuffer = MemoryUtil.memAllocFloat(vertices.length * 3);
		float[] positionData = new float[vertices.length * 3];
		for (int i = 0; i < vertices.length; i++) {
			positionData[i * 3] = vertices[i].getX();
			positionData[i * 3 + 1] = vertices[i].getY();
			positionData[i * 3 + 2] = vertices[i].getZ();
		}
		positionBuffer.put(positionData).flip();
		
		pb = new DataBuffer(positionBuffer, 0, 3);
		pb.create();
		
		FloatBuffer textureBuffer = MemoryUtil.memAllocFloat(vertices.length * 2);
		float[] textureData = new float[vertices.length * 2];
		for (int i = 0; i < vertices.length; i++) {
			textureData[i * 2] = vertices[i].getMap().getX();
			textureData[i * 2 + 1] = vertices[i].getMap().getY();
		}
		textureBuffer.put(textureData).flip();
		
		tb = new DataBuffer(textureBuffer, 2, 2);
		tb.create();
		
		IntBuffer indicesBuffer = MemoryUtil.memAllocInt(indices.length);
		indicesBuffer.put(indices).flip();
		
		ib = new DataBuffer(indicesBuffer);
		ib.create();
	}
	
	public void destroy() {
		pb.destroy();
		ib.destroy();
		tb.destroy();
		GL30.glDeleteVertexArrays(vao);
	}

	public void setRot(V3f rot) {
		this.rot = rot;
	}
	public void setFrame(boolean frame) {
		this.frame = frame;
	}
	
	public boolean isFrame() {
		return frame;
	}
	public Vertex[] getVertices() {
		return vertices;
	}
	public V3f getRot() {
		return rot;
	}
	public int[] getIndices() {
		return indices;
	}
	public int getVAO() {
		return vao;
	}
	public DataBuffer getPB() {
		return pb;
	}
	public DataBuffer getTB() {
		return tb;
	}
	public DataBuffer getIB() {
		return ib;
	}
	public Mat getMat() {
		return mat;
	}
}
