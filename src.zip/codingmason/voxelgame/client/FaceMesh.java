package codingmason.voxelgame.client;

class FaceMesh {
	private int[] indicies;
	private Mat mat;
	private DataBuffer ib;
	
	public FaceMesh(int[] indicies, Mat mat, DataBuffer ib) {
		this.ib = ib;
		this.indicies = indicies;
		this.mat = mat;
	}
	
	public void destroy() {
		ib.destroy();
	}
	
	public Mat getMat() {
		return mat;
	}
	public int[] getIndicies() {
		return indicies;
	}
	public DataBuffer getIB() {
		return ib;
	}
}
