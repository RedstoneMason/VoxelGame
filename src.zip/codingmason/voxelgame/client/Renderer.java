package codingmason.voxelgame.client;

import org.lwjgl.opengl.GL30;

import codingmason.gdt.vectors.V3f;
import codingmason.gdt.vectors.V4f;

class Renderer {
	private Shader shader;
	private Camera cam;
	private V3f scale = new V3f(1, 1, 1);
	
	public Renderer(Shader shader, Matrix proj, Camera cam) {
		this.shader = shader;
		shader.bind();
		this.cam = cam;
		setProjection(proj);
	}
	
	public void setCam(Camera cam) {
		this.cam = cam;
	}
	public void setProjection(Matrix proj) {
		shader.setUniform("projection", proj);
	}
	
	public void update() {
		shader.setUniform("view", Matrix.view(cam.getPos(), cam.getRot()));
	}
	
	public void renderChunkMesh(ChunkMesh mesh) {
		shader.setUniform("setColor", new V4f(-10, -10, -10, -10));
		GL30.glEnableVertexAttribArray(0);
		GL30.glEnableVertexAttribArray(1);
		GL30.glEnableVertexAttribArray(2);
		GL30.glBindVertexArray(mesh.getVAO());
		shader.setUniform("model", Matrix.transform(new V3f(0, 0, 0), new V3f(0, 0, 0), scale));
		for(FaceMesh fm : mesh.getFaceMeshs()) {
			GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, fm.getIB().getID());
			GL30.glActiveTexture(GL30.GL_TEXTURE0);
			fm.getMat().bind();
			GL30.glDrawElements(GL30.GL_TRIANGLES, fm.getIndicies().length, GL30.GL_UNSIGNED_INT, 0);
			fm.getMat().unbind();
		}
	}
	
	public void renderMesh(BasicMesh mesh) {
		shader.setUniform("setColor", new V4f(-10, -10, -10, -10));
		GL30.glEnableVertexAttribArray(0);
		GL30.glEnableVertexAttribArray(1);
		GL30.glEnableVertexAttribArray(2);
		GL30.glBindVertexArray(mesh.getVAO());
		GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, mesh.getIB().getID());
		GL30.glActiveTexture(GL30.GL_TEXTURE0);
		mesh.getMat().bind();
		shader.setUniform("model", Matrix.transform(new V3f(0, 0, 0), mesh.getRot(), scale));
		GL30.glDrawElements(mesh.isFrame() ? GL30.GL_LINES : GL30.GL_TRIANGLES, mesh.getIndices().length, GL30.GL_UNSIGNED_INT, 0);
		GL30.glBindTexture(GL30.GL_TEXTURE_2D, 0);
	}
	
	public void renderColorMesh(ColorMesh mesh) {
		GL30.glDisable(GL30.GL_TEXTURE_2D);
		GL30.glEnableVertexAttribArray(0);
		GL30.glEnableVertexAttribArray(1);
		GL30.glEnableVertexAttribArray(2);
		GL30.glBindVertexArray(mesh.getVAO());
		GL30.glBindBuffer(GL30.GL_ELEMENT_ARRAY_BUFFER, mesh.getIB().getID());
		shader.setUniform("model", Matrix.transform(new V3f(0, 0, 0), mesh.getRot(), scale));
		shader.setUniform("setColor", mesh.getColor());
		GL30.glDrawElements(mesh.isFrame() ? GL30.GL_LINES : GL30.GL_TRIANGLES, mesh.getIndices().length, GL30.GL_UNSIGNED_INT, 0);
		GL30.glEnable(GL30.GL_TEXTURE_2D);
	}
	
	public Shader getShader() {
		return shader;
	}
}
