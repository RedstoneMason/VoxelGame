package codingmason.voxelgame.client;

import java.util.Arrays;
import java.util.stream.IntStream;

import codingmason.gdt.vectors.V3f;

class Matrix {
	private float[][] elements;
	private int size;
	
	public Matrix(int size) {
		this.size = size;
		elements = new float[size][size];
	}
	public Matrix(float[][] elements) {
		this.elements = elements;
		this.size = elements.length;
	}
	
	public static float[] normalize(float[] arr) {
		float sq = 0;
		for(float f : arr) sq += Math.pow(f, 2);
		sq = (float)Math.sqrt(sq);
		float[] result = arr.clone();
		for(int i = 0; i < result.length; i++) result[i] /= sq;
		return result;
	}
	
	public static Matrix identity() {
		int size = 4;
		Matrix result = new Matrix(size);
		
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < size; j++) {
				result.set(i, j, 0);
			}
		}
		
		result.set(0, 0, 1);
		result.set(1, 1, 1);
		result.set(2, 2, 1);
		result.set(3, 3, 1);
		
		return result;
	}
	
	public static Matrix translate(V3f translate) {
		Matrix result = Matrix.identity();
		result.set(3, 0, translate.getX());
		result.set(3, 1, translate.getY());
		result.set(3, 2, translate.getZ());
		return result;
	}
	
	public static Matrix rotate(float angle, V3f axis) {
		Matrix result = Matrix.identity();
		
		float cos = (float) Math.cos(Math.toRadians(angle));
		float sin = (float) Math.sin(Math.toRadians(angle));
		float C = 1 - cos;
		
		result.set(0, 0, cos + axis.getX() * axis.getX() * C);
		result.set(0, 1, axis.getX() * axis.getY() * C - axis.getZ() * sin);
		result.set(0, 2, axis.getX() * axis.getZ() * C + axis.getY() * sin);
		result.set(1, 0, axis.getY() * axis.getX() * C + axis.getZ() * sin);
		result.set(1, 1, cos + axis.getY() * axis.getY() * C);
		result.set(1, 2, axis.getY() * axis.getZ() * C - axis.getX() * sin);
		result.set(2, 0, axis.getZ() * axis.getX() * C - axis.getY() * sin);
		result.set(2, 1, axis.getZ() * axis.getY() * C + axis.getX() * sin);
		result.set(2, 2, cos + axis.getZ() * axis.getZ() * C);
		
		return result;
	}
	
	public static Matrix scale(V3f scalar) {
		Matrix result = Matrix.identity();
		result.set(0, 0, scalar.getX());
		result.set(1, 1, scalar.getY());
		result.set(2, 2, scalar.getZ());
		return result;
	}
	
	public static Matrix transform(V3f position, V3f rotation, V3f scale) {
		Matrix result = Matrix.identity();
		
		Matrix translationMatrix = Matrix.translate(position);
		Matrix rotXMatrix = Matrix.rotate(rotation.getX(), new V3f(1, 0, 0));
		Matrix rotYMatrix = Matrix.rotate(rotation.getY(), new V3f(0, 1, 0));
		Matrix rotZMatrix = Matrix.rotate(rotation.getZ(), new V3f(0, 0, 1));
		Matrix scaleMatrix = Matrix.scale(scale);
		
		Matrix rotationMatrix = Matrix.mult(rotXMatrix, Matrix.mult(rotYMatrix, rotZMatrix));
		
		result = Matrix.mult(translationMatrix, Matrix.mult(rotationMatrix, scaleMatrix));
		
		return result;
	}
	
	public static Matrix projection(float fov, float aspect, float near, float far) {
		Matrix result = Matrix.identity();
		float tanFOV = (float)Math.tan(Math.toRadians(fov / 2));
		float range = far - near;
		
		result.set(0, 0, 1.0f / (aspect * tanFOV));
		result.set(1, 1, 1.0f / tanFOV);
		result.set(2, 2, -((far + near) / range));
		result.set(2, 3, -1.0f);
		result.set(3, 2, -((2 * far * near) / range));
		result.set(3, 3, 0.0f);
		return result;
	}
	
	public static Matrix view(V3f position, V3f rotation) {
		V3f negative = new V3f(-position.getX(), -position.getY(), -position.getZ());
		Matrix translationMatrix = Matrix.translate(negative);
		Matrix rotXMatrix = Matrix.rotate(rotation.getX(), new V3f(1, 0, 0));
		Matrix rotYMatrix = Matrix.rotate(rotation.getY(), new V3f(0, 1, 0));
		Matrix rotZMatrix = Matrix.rotate(rotation.getZ(), new V3f(0, 0, 1));
		
		Matrix rotationMatrix = Matrix.mult(rotYMatrix, Matrix.mult(rotZMatrix, rotXMatrix));
		
		return Matrix.mult(translationMatrix, rotationMatrix);
	}
	
	public static Matrix mult(Matrix matrix, Matrix other) {
		Matrix result = Matrix.identity();
		for(int i = 0; i < matrix.size; i++) {
			for(int j = 0; j < matrix.size; j++) {
				result.set(i, j, matrix.get(i, 0) * other.get(0, j) +
								 matrix.get(i, 1) * other.get(1, j) +
								 matrix.get(i, 2) * other.get(2, j) +
								 matrix.get(i, 3) * other.get(3, j));
			}
		}
		return result;
	}
	
	public static float[] multiply(Matrix matrix, float[] vector) {
	    double[] arr = Arrays.stream(matrix.getElements())
	                 .mapToDouble(row -> 
	                    IntStream.range(0, row.length)
	                             .mapToDouble(col -> row[col] * vector[col])
	                             .sum()
	                 ).toArray();
	    float[] result = new float[arr.length];
	    for(int i = 0; i < arr.length; i++) result[i] = (float)arr[i];
	    return result;
	}
	
	private static float determinant(Matrix matrix) {
        if (matrix.size == 2)
            return matrix.elements[0][0] * matrix.elements[1][1] - matrix.elements[0][1] * matrix.elements[1][0];

        float det = 0;
        for (int i = 0; i < matrix.size; i++)
            det += Math.pow(-1, i) * matrix.elements[0][i]
                    * determinant(minor(matrix, 0, i));
        return det;
    }

    public static Matrix inverse(Matrix matrix) {
        float[][] inverse = new float[matrix.size][matrix.size];

        // minors and cofactors
        for (int i = 0; i < matrix.size; i++)
            for (int j = 0; j < matrix.size; j++)
                inverse[i][j] = (float)Math.pow(-1, i + j) * determinant(minor(matrix, i, j));

        // adjugate and determinant
        float det = 1.0f / determinant(matrix);
        for (int i = 0; i < inverse.length; i++) {
            for (int j = 0; j <= i; j++) {
                float temp = inverse[i][j];
                inverse[i][j] = inverse[j][i] * det;
                inverse[j][i] = temp * det;
            }
        }

        return new Matrix(inverse);
    }

    private static Matrix minor(Matrix matrix, int row, int column) {
        float[][] minor = new float[matrix.size-1][matrix.size-1];

        for (int i = 0; i < matrix.size; i++)
            for (int j = 0; i != row && j < matrix.size; j++)
                if (j != column)
                    minor[i < row ? i : i - 1][j < column ? j : j - 1] = matrix.elements[i][j];
        return new Matrix(minor);
    }

	public float get(int x, int y) {
		return elements[y][x];
	}
	public void set(int x, int y, float value) {
		elements[y][x] = value;
	}
	public float[] getAll() {
		float[] all = new float[size*size];
		for(int x = 0; x < size; x++) 
			for(int y = 0; y < size; y++)
				all[x+y*size] = elements[y][x];
		return all;
	}
	public float[][] getElements() {
		return elements;
	}
	public int getSize() {
		return size;
	}
}