package codingmason.voxelgame;

import java.util.Arrays;
import java.util.LinkedList;

public class World {
	private LinkedList<Chunk> chunks = new LinkedList<>();
	private String name;
	
	public World(String name) {
		this.name = name;
	}
	
	public void setChunksStr(String chunks) {
		this.chunks.clear();
		chunks = chunks.substring(3, chunks.length()-1);
		for(String s : chunks.split("\\.")) {
			this.chunks.add(new Chunk(s, this));
		}
	}
	
	public void addChunk(Chunk chunk) {
		this.chunks.add(chunk);
	}
	
	public String getName() {
		return name;
	}
	
	public String getProperties() {
		return "[\""+name+"\"]";
	}
	
	public String getTile(int x, int y, int z) {
		for(Chunk c : chunks) {
			int cx = x-c.x*Data.CHUNK_WIDTH, cy = y-c.y*Data.CHUNK_HEIGHT, cz = z-c.z*Data.CHUNK_DEPTH;
			if(c.contains(cx, cy, cz)) {
				return c.getTile(cx, cy, cz);
			}
		}
		return Tile.air+"";
	}
	public void setTile(int x, int y, int z, String tile) {
		for(Chunk c : chunks) {
			int cx = x-c.x*Data.CHUNK_WIDTH, cy = y-c.y*Data.CHUNK_HEIGHT, cz = z-c.z*Data.CHUNK_DEPTH;
			if(c.contains(cx, cy, cz)) {
				c.setTile(x, y, z, tile);
			}
		}
	}
	
	public Chunk contains(int x, int y, int z) {
		for(Chunk c : chunks) {
			if(c.contains(x-c.x*Data.CHUNK_WIDTH, y-c.y*Data.CHUNK_HEIGHT, z-c.z*Data.CHUNK_DEPTH)) return c;
		}
		return null;
	}
	
	public LinkedList<Chunk> getChunks() {
		return chunks;
	}
	
	public String getChunksStr() {
		return Arrays.toString(chunks.toArray(new Chunk[] {})).replace(", ", ".");
	}
}
