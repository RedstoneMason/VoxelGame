package codingmason.voxelgame;

import java.util.Arrays;

public class Chunk {
	private static final int WIDTH = Data.CHUNK_WIDTH, HEIGHT = Data.CHUNK_HEIGHT, DEPTH = Data.CHUNK_DEPTH;
	public final int x, y, z;
	public String[] tiles = new String[WIDTH*HEIGHT*DEPTH];
	private World world;
	
	public Chunk(int x, int y, int z, World world) {
		this.x = x; 
		this.y = y; 
		this.z = z; 
		this.world = world;
	}
	public Chunk(String chunk, World world) {
		this.world = world;
		String[] data = chunk.split(",");
		this.x = Integer.parseInt(data[0]);
		this.y = Integer.parseInt(data[1]);
		this.z = Integer.parseInt(data[2]);
		this.tiles = data[3].substring(1, data[3].length()-1).split("-");
	}
	
	public void setTiles(String[] tiles) {
		this.tiles = tiles;
	}
	public boolean contains(int x, int y, int z) {
		return (x >= 0 & x < WIDTH & y >= 0 & y < HEIGHT & z >= 0 & z < DEPTH);
	}
	public void setTile(int x, int y, int z, String tile) {
		if(contains(x, y, z)) tiles[x+y*WIDTH+z*WIDTH*HEIGHT] = tile;
	}
	public String getTile(int x, int y, int z) {
		if(contains(x, y, z)) return tiles[x+y*WIDTH+z*WIDTH*HEIGHT];
		return world.getTile(x+this.x*WIDTH, y+this.y*HEIGHT, z+this.z*DEPTH);
	}
	public String toString() {
		return x+","+y+","+z+","+Arrays.toString(tiles).replace(", ", "-");
	}
}
